# Vendor Stock Management React Frontend

Built directly from the uploaded Vendor Stock Management API documentation.

## Backend
Base URL: `http://localhost:5000`

Create `.env` from `.env.example` when needed:
```env
VITE_API_URL=http://localhost:5000
```

## Run
```bash
npm install
npm run dev
```
Open `http://localhost:5173`.

## Panels

**Vendor**
- Register/login
- Product list
- Add product
- Edit product
- Delete product

**Seller**
- Register/login
- Active product shop
- Product details
- Add/update/remove cart items
- Checkout
- Order history/details

**Admin**
- Login with backend-created admin
- Product activate/block
- View all orders
- Update order status: confirmed, shipped, delivered, cancelled

## API integration
Axios automatically sends `Authorization: Bearer <token>` after login.

The project uses these documented endpoints:
- `/`
- `/api/auth/register`
- `/api/auth/login`
- `/api/auth/me`
- `/api/products`
- `/api/products/:id`
- `/api/products/:id/status`
- `/api/cart`
- `/api/cart/:productId`
- `/api/orders`
- `/api/orders/:id`
- `/api/orders/admin/all`
- `/api/orders/admin/:id/status`

Admin registration is intentionally not provided because the documentation says admin creation is not allowed through the registration API.

## CORS
If the browser shows CORS errors, the backend must allow the Vite origin:
`http://localhost:5173`
