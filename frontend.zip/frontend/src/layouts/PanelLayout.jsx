import { NavLink, Outlet } from "react-router-dom";
import Topbar from "../components/Topbar";

const menus = {
  vendor: [["/vendor","Dashboard","bi-speedometer2"],["/vendor/products","My Products","bi-box-seam"],["/vendor/products/add","Add Product","bi-plus-circle"]],
  seller: [["/seller","Shop","bi-shop"],["/seller/cart","Cart","bi-cart3"],["/seller/orders","My Orders","bi-receipt"]],
  admin: [["/admin","Dashboard","bi-speedometer2"],["/admin/products","Products","bi-boxes"],["/admin/orders","Orders","bi-receipt"]]
};

export default function PanelLayout({ role }) {
  return <div className="app-shell">
    <Topbar title={`${role} panel`} />
    <div className="d-flex">
      <aside className="sidebar p-3">
        <div className="small text-uppercase text-secondary fw-bold mb-2">{role} menu</div>
        {menus[role].map(([to,label,icon]) =>
          <NavLink key={to} to={to} end={to===`/${role}`} className={({isActive})=>`side-link ${isActive?"active":""}`}>
            <i className={`bi ${icon}`}></i><span>{label}</span>
          </NavLink>
        )}
      </aside>
      <main className="content flex-grow-1"><Outlet /></main>
    </div>
  </div>;
}