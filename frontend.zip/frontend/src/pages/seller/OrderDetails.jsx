import { useEffect,useState } from "react";
import { useParams } from "react-router-dom";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

export default function OrderDetails(){
  const {id}=useParams();const [order,setOrder]=useState(null);
  useEffect(()=>{API.get(`/api/orders/${id}`).then(r=>setOrder(r.data.data)).catch(e=>alert(getApiError(e)))},[id]);
  if(!order)return <div>Loading...</div>;
  return <div className="card border-0 shadow-sm"><div className="card-body"><h2>Order Details</h2><p className="text-muted">{order._id}</p>
    {order.items?.map((i,n)=><div className="d-flex justify-content-between border-bottom py-2" key={n}><span>{i.name} × {i.quantity}</span><strong>₹{(Number(i.price)*Number(i.quantity)).toLocaleString()}</strong></div>)}
    <h4 className="text-end mt-3">₹{Number(order.totalAmount).toLocaleString()}</h4><span className="badge text-bg-primary text-uppercase">{order.status}</span>
  </div></div>;
}