import { useEffect,useState } from "react";
import { Link } from "react-router-dom";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

export default function Orders(){
  const [orders,setOrders]=useState([]);
  useEffect(()=>{API.get("/api/orders").then(r=>setOrders(r.data.data||[])).catch(e=>alert(getApiError(e)))},[]);
  return <><h2 className="fw-bold">My Orders</h2><div className="card border-0 shadow-sm"><div className="table-responsive"><table className="table align-middle mb-0">
    <thead><tr><th>Order ID</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>{orders.map(o=><tr key={o._id}><td className="small">{o._id}</td><td>₹{Number(o.totalAmount).toLocaleString()}</td><td><span className="badge text-bg-light text-uppercase">{o.status}</span></td><td><Link to={`/seller/orders/${o._id}`} className="btn btn-sm btn-outline-primary">Details</Link></td></tr>)}
    {!orders.length&&<tr><td colSpan="4" className="text-center text-muted py-4">No orders yet.</td></tr>}</tbody></table></div></div></>;
}