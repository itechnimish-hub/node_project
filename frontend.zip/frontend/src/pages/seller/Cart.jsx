import { useEffect,useState } from "react";
import { Link,useNavigate } from "react-router-dom";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

export default function Cart(){
  const [cart,setCart]=useState(null),navigate=useNavigate();
  const load=()=>API.get("/api/cart").then(r=>setCart(r.data.data)).catch(e=>alert(getApiError(e)));
  useEffect(load,[]);
  const update=async(id,q)=>{try{await API.put(`/api/cart/${id}`,{quantity:Number(q)});load()}catch(e){alert(getApiError(e))}};
  const remove=async id=>{try{await API.delete(`/api/cart/${id}`);load()}catch(e){alert(getApiError(e))}};
  const checkout=async()=>{try{const r=await API.post("/api/orders");alert(r.data.message||"Order placed");navigate("/seller/orders")}catch(e){alert(getApiError(e))}};
  const items=cart?.items||[],total=items.reduce((s,i)=>s+Number(i.product?.price||0)*Number(i.quantity||0),0);
  return <><h2 className="fw-bold">My Cart</h2><div className="card border-0 shadow-sm"><div className="card-body">
    {!items.length?<p className="text-muted mb-0">Your cart is empty. <Link to="/seller">Browse products</Link></p>:<>{items.map(i=><div className="cart-row" key={i.product._id}>
      <div><strong>{i.product.name}</strong><div className="small text-muted">₹{Number(i.product.price).toLocaleString()}</div></div>
      <input className="form-control quantity-input" type="number" min="1" max={i.product.stock} value={i.quantity} onChange={e=>update(i.product._id,e.target.value)}/>
      <strong>₹{(Number(i.product.price)*Number(i.quantity)).toLocaleString()}</strong><button className="btn btn-sm btn-outline-danger" onClick={()=>remove(i.product._id)}>Remove</button>
    </div>)}<div className="text-end pt-3 mt-3 border-top"><h4>Total: ₹{total.toLocaleString()}</h4><button className="btn btn-success" onClick={checkout}>Checkout</button></div></>}
  </div></div></>;
}