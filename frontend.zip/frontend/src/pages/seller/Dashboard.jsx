
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

export default function Dashboard() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        // baseURL already includes /api/
        const response = await API.get("products/my-products");

        console.log("Products API response:", response.data);

        const result = response.data?.data ?? response.data;
        const productList = Array.isArray(result)
          ? result
          : result?.products ?? [];

        setProducts(productList);
      } catch (e) {
        console.error("Products error:", e);
        setError(getApiError(e, "Failed to load products."));
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  if (loading) {
    return <p>Loading products...</p>;
  }

  if (error) {
    return <div className="alert alert-danger">{error}</div>;
  }

  return (
    <>
      <h2 className="fw-bold">Seller Shop</h2>
      <p className="text-muted">
        View active products and add them to your cart.
      </p>

      {products.length === 0 ? (
        <div className="alert alert-info">
          No active products are available.
        </div>
      ) : (
        <div className="row g-4">
          {products.map((p) => (
            <div className="col-md-6 col-xl-4" key={p._id}>
              <div className="card h-100 border-0 shadow-sm">
                <div className="product-placeholder d-flex justify-content-center align-items-center">
                  <i className="bi bi-box-seam fs-1"></i>
                </div>

                <div className="card-body">
                  <h5>{p.name}</h5>
                  <p className="text-muted small">
                    {p.description}
                  </p>

                  <div className="d-flex justify-content-between align-items-center">
                    <strong>
                      ₹{Number(p.price || 0).toLocaleString("en-IN")}
                    </strong>

                    <Link
                      className="btn btn-sm btn-primary"
                      to={`/seller/products/${p._id}`}
                    >
                      View
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
