import { useEffect,useState } from "react";
import { useParams,Link } from "react-router-dom";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

export default function ProductDetails(){
  const {id}=useParams();const [p,setP]=useState(null);const [quantity,setQuantity]=useState(1);
  useEffect(()=>{API.get(`/api/products/${id}`).then(r=>setP(r.data.data)).catch(e=>alert(getApiError(e)))},[id]);
  const add=async()=>{try{await API.post("/api/cart",{productId:id,quantity:Number(quantity)});alert("Product added to cart")}catch(e){alert(getApiError(e))}};
  if(!p)return <div>Loading...</div>;
  return <div className="card border-0 shadow-sm"><div className="card-body p-4"><Link to="/seller" className="btn btn-sm btn-light mb-3">← Back</Link>
    <h2>{p.name}</h2><p className="text-muted">{p.description}</p><h4>₹{Number(p.price).toLocaleString()}</h4><p>Available stock: <strong>{p.stock}</strong></p>
    <div className="d-flex gap-2 align-items-center"><input className="form-control quantity-input" type="number" min="1" max={p.stock} value={quantity} onChange={e=>setQuantity(e.target.value)}/>
    <button className="btn btn-primary" disabled={!p.active||p.stock<1} onClick={add}>Add to Cart</button></div>
  </div></div>;
}