
import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import API from "../../services/api";
import { saveAuth, roleHome } from "../../utils/auth";
import { getApiError } from "../../utils/apiError";

export default function Login() {
  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data } = await API.post("auth/login", form);

      console.log("API Response:", data);

      // Save token and user
      saveAuth(data);

      // IMPORTANT: Your API returns user directly
      const role = data?.user?.role?.toLowerCase();
      const requested = location.state?.from;

      console.log("Role:", role);

      if (!role) {
        throw new Error("User role is missing.");
      }

      const destination = 
        requested && role === "seller"
          ? requested
          : roleHome(role);

      console.log("Redirecting to:", destination);

      navigate(destination, { replace: true });

    } catch (error) {
      console.error("Login error:", error);
      alert(getApiError(error, "Invalid email or password."));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card card border-0 shadow">
        <div className="card-body p-4 p-md-5">

          <div className="text-center mb-4">
            <div className="brand-icon">
              <i className="bi bi-boxes"></i>
            </div>

            <h2 className="fw-bold mt-3">StockPro</h2>
            <p className="text-muted">
              Vendor Stock Management
            </p>
          </div>

          <form onSubmit={submit}>
            <label className="form-label">Email</label>

            <input
              className="form-control mb-3"
              type="email"
              value={form.email}
              onChange={(e) =>
                setForm({ ...form, email: e.target.value })
              }
              required
            />

            <label className="form-label">Password</label>

            <input
              className="form-control mb-3"
              type="password"
              value={form.password}
              onChange={(e) =>
                setForm({ ...form, password: e.target.value })
              }
              required
            />

            <button
              className="btn btn-primary w-100"
              disabled={loading}
            >
              {loading ? "Signing in..." : "Login"}
            </button>
          </form>

          <p className="text-center text-muted mt-4 mb-0">
            Need an account?{" "}
            <Link to="/register">Register Vendor/Seller</Link>
          </p>

        </div>
      </div>
    </div>
  );
}
