import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import API from "../../services/api";
import { saveAuth, roleHome } from "../../utils/auth";
import { getApiError } from "../../utils/apiError";

export default function Register() {

  const [form,setForm]=useState({name:"",email:"",password:"",role:""}), [loading,setLoading]=useState(false);
  const navigate=useNavigate();
  const submit=async e=>{
    e.preventDefault(); setLoading(true);
    try { 
      const { data } = await API.post("auth/register", form);
      saveAuth(data); 
      navigate(roleHome(data?.data?.user?.role),{replace:true});
     }
    catch(e){ alert(getApiError(e,"Registration failed.")); } finally{setLoading(false);}
  };
  return <div className="auth-page"><div className="auth-card card border-0 shadow"><div className="card-body p-4 p-md-5">
    <h2 className="fw-bold">Create account</h2><p className="text-muted">Admin registration is not allowed by the API.</p>
    <form onSubmit={submit}>
      <input className="form-control mb-3" placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/>
      <input className="form-control mb-3" type="email" placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/>
      <input className="form-control mb-3" type="password" placeholder="Password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required/>
      <select className="form-select mb-3" value={form.role} onChange={e=>setForm({...form,role:e.target.value})}><option value="vendor">Vendor</option><option value="seller">Seller</option></select>
      <button className="btn btn-primary w-100" disabled={loading}>{loading?"Creating...":"Create Account"}</button>
    </form>
    <p className="text-center mt-3 mb-0"><Link to="/login">Back to login</Link></p>
  </div></div></div>;
}