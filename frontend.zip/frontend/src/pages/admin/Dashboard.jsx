import { useEffect,useState } from "react";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

export default function Dashboard(){
  const [products,setProducts]=useState([]),[orders,setOrders]=useState([]);
  useEffect(()=>{Promise.all([API.get("/api/products"),API.get("/api/orders/admin/all")]).then(([p,o])=>{setProducts(p.data.data||[]);setOrders(o.data.data||[])}).catch(e=>alert(getApiError(e)))},[]);
  return <><h2 className="fw-bold">Admin Dashboard</h2><div className="row g-3">
    <div className="col-md-4"><div className="stat-card"><span>Total Products</span><strong>{products.length}</strong></div></div>
    <div className="col-md-4"><div className="stat-card"><span>Active Products</span><strong>{products.filter(p=>p.active).length}</strong></div></div>
    <div className="col-md-4"><div className="stat-card"><span>Orders</span><strong>{orders.length}</strong></div></div>
  </div></>;
}