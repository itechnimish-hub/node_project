import { useEffect,useState } from "react";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

const statuses=["confirmed","shipped","delivered","cancelled"];

export default function Orders(){
  const [orders,setOrders]=useState([]);
  const load=()=>API.get("/api/orders/admin/all").then(r=>setOrders(r.data.data||[])).catch(e=>alert(getApiError(e)));
  useEffect(load,[]);
  const update=async(id,status)=>{try{await API.patch(`/api/orders/admin/${id}/status`,{status});load()}catch(e){alert(getApiError(e))}};
  return <><h2 className="fw-bold">Order Management</h2><div className="card border-0 shadow-sm"><div className="table-responsive"><table className="table align-middle mb-0">
    <thead><tr><th>Order</th><th>Seller</th><th>Total</th><th>Status</th><th>Update</th></tr></thead><tbody>
    {orders.map(o=><tr key={o._id}><td className="small">{o._id}</td><td>{o.user?.name}<br/><small>{o.user?.email}</small></td><td>₹{Number(o.totalAmount).toLocaleString()}</td><td><span className="badge text-bg-light text-uppercase">{o.status}</span></td>
    <td><select className="form-select form-select-sm" value="" onChange={e=>e.target.value&&update(o._id,e.target.value)}><option value="">Change status</option>{statuses.map(s=><option key={s}>{s}</option>)}</select></td></tr>)}
    {!orders.length&&<tr><td colSpan="5" className="text-center text-muted py-4">No orders.</td></tr>}</tbody></table></div></div></>;
}