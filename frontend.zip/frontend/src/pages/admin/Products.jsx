import { useEffect,useState } from "react";
import API from "../../services/api";
import { getApiError } from "../../utils/apiError";

export default function Products(){
  const [products,setProducts]=useState([]);
  const load=()=>API.get("/api/products").then(r=>setProducts(r.data.data||[])).catch(e=>alert(getApiError(e)));
  useEffect(load,[]);
  const setStatus=async(p,active)=>{try{await API.patch(`/api/products/${p._id}/status`,{active});load()}catch(e){alert(getApiError(e))}};
  return <><h2 className="fw-bold">Product Management</h2><p className="text-muted">Admin can activate or block products.</p>
    <div className="card border-0 shadow-sm"><div className="table-responsive"><table className="table align-middle mb-0"><thead><tr><th>Product</th><th>Vendor</th><th>Price</th><th>Stock</th><th>Status</th><th>Action</th></tr></thead><tbody>
    {products.map(p=><tr key={p._id}><td><strong>{p.name}</strong></td><td>{p.vendor?.name||"-"}</td><td>₹{Number(p.price).toLocaleString()}</td><td>{p.stock}</td><td><span className={`badge ${p.active?"text-bg-success":"text-bg-secondary"}`}>{p.active?"Active":"Blocked"}</span></td>
    <td><button className={`btn btn-sm ${p.active?"btn-outline-danger":"btn-outline-success"}`} onClick={()=>setStatus(p,!p.active)}>{p.active?"Block":"Activate"}</button></td></tr>)}
    </tbody></table></div></div></>;
}