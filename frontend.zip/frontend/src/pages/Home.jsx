import { Link } from "react-router-dom";
import { getUser } from "../utils/auth";

export default function Home() {
  const user = getUser();
  return <div className="landing"><div className="container py-5">
    <div className="hero-card p-4 p-md-5 shadow-sm">
      <span className="badge text-bg-primary mb-3">Vendor Stock Management</span>
      <h1 className="display-5 fw-bold">Manage products, carts and orders from one app.</h1>
      <p className="lead text-muted mt-3">React frontend integrated with the documented Node/Express API.</p>
      <Link className="btn btn-primary" to={user ? `/${user.role}` : "/login"}>{user ? `Open ${user.role} panel` : "Login to continue"}</Link>
    </div>
  </div></div>;
}