import { Navigate, Route, Routes } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import PanelLayout from "./layouts/PanelLayout";
import Home from "./pages/Home";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import VendorDashboard from "./pages/vendor/Dashboard";
import VendorProducts from "./pages/vendor/Products";
import ProductForm from "./pages/vendor/ProductForm";
import SellerDashboard from "./pages/seller/Dashboard";
import SellerProductDetails from "./pages/seller/ProductDetails";
import Cart from "./pages/seller/Cart";
import SellerOrders from "./pages/seller/Orders";
import SellerOrderDetails from "./pages/seller/OrderDetails";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminProducts from "./pages/admin/Products";
import AdminOrders from "./pages/admin/Orders";

export default function App(){
  return <Routes>
    <Route path="/" element={<Home/>}/><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/>
    <Route element={<ProtectedRoute roles={["vendor"]}/>}>
      <Route element={<PanelLayout role="vendor" />}><Route path="/vendor" element={<VendorDashboard/>}/><Route path="/vendor/products" element={<VendorProducts/>}/><Route path="/vendor/products/add" element={<ProductForm/>}/><Route path="/vendor/products/edit/:id" element={<ProductForm edit/>}/></Route>
    </Route>
    <Route element={<ProtectedRoute roles={["seller"]}/>}>
      <Route element={<PanelLayout role="seller" />}><Route path="/seller" element={<SellerDashboard/>}/><Route path="/seller/products/:id" element={<SellerProductDetails/>}/><Route path="/seller/cart" element={<Cart/>}/><Route path="/seller/orders" element={<SellerOrders/>}/><Route path="/seller/orders/:id" element={<SellerOrderDetails/>}/></Route>
    </Route>
    <Route element={<ProtectedRoute roles={["admin"]}/>}>
      <Route element={<PanelLayout role="admin" />}><Route path="/admin" element={<AdminDashboard/>}/><Route path="/admin/products" element={<AdminProducts/>}/><Route path="/admin/orders" element={<AdminOrders/>}/></Route>
    </Route>
    <Route path="*" element={<Navigate to="/" replace/>}/>
  </Routes>;
}