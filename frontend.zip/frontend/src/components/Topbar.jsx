import { Link, useNavigate } from "react-router-dom";
import { getUser, logout } from "../utils/auth";

export default function Topbar({ title }) {
  const navigate = useNavigate(), user = getUser();
  const handleLogout = () => { logout(); navigate("/login", { replace: true }); };
  return <nav className="navbar bg-white border-bottom px-3 px-lg-4 py-3 sticky-top">
    <div className="container-fluid">
      <Link className="navbar-brand fw-bold text-primary" to="/">StockPro</Link>
      <div className="d-flex align-items-center gap-3">
        <span className="d-none d-md-inline text-muted">{title}</span>
        <span className="badge text-bg-light text-uppercase">{user?.role}</span>
        <button className="btn btn-outline-danger btn-sm" onClick={handleLogout}>Logout</button>
      </div>
    </div>
  </nav>;
}