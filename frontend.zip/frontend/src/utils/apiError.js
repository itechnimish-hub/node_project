export const getApiError = (error, fallback = "Something went wrong") =>
  error?.response?.data?.message || error?.response?.data?.error || error?.message || fallback;