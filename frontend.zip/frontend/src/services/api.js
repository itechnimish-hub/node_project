import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api/",
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  // IMPORTANT:
  // Do NOT force application/json when sending FormData.
  if (config.data instanceof FormData) {
    delete config.headers["Content-Type"];
  }

  return config;
});

export default API;